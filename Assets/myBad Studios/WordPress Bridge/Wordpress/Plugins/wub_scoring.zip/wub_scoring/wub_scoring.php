<?php

session_start();

/*
Plugin Name: WordPress For Unity Bridge - Scores
Plugin URI: https://mybadstudios.com/
Description: Store and retrieve any/all of your Unity game's high scores into your WordPress database
Version: 1
Author: myBad Studios
Network: true
Author URI: https://mybadstudios.com
*/

include_once(dirname(__FILE__) ."/settings.php");
include_once(dirname(__FILE__) ."/classes/WubHighscores.class.php");
include_once(dirname(__FILE__) ."/scoring_web_functions.php");
include_once('Settings/widgets.php');

add_action( 'wp_enqueue_scripts', 'enqueue_wub_scoring_styles' );

function enqueue_wub_scoring_styles()
{
	wp_register_style ( 'wub_scoring_stylesheet', plugins_url('wub_scoring/style.css'));
	wp_enqueue_style ( 'wub_scoring_stylesheet' );
}
