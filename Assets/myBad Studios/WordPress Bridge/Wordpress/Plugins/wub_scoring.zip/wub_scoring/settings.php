<?php		
    include_once(dirname(__FILE__) . "/../wub_login/functions.php");
    include_once("Settings/wub_scoring.php");

    add_filter("wub_section_heading", "wub_add_scoring_menu",16,2);
    add_filter("wub_section_content", "wub_show_scoring_section", 18, 2);
    
    function wub_add_scoring_menu($value)
    {
        $menu_button = new WubMenuItem('Leaderboards');
        return $value . $menu_button->GenerateMenuButton();
    }
    
    function wub_show_scoring_section($content)
    {
        return (MENUTAB == LEADERBOARDS_CONSTANT) ? show_wub_scoring_content() : $content;
    }
